package AbstractMethod;

import java.util.Scanner;

//Abstract Class
abstract class bank{

    //Abstract method
    abstract double axisBank();

    abstract double hdfcBank();

    abstract double sbiBank();

    abstract double indianBank();

    //Non-Abstract method
    public String studentName(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Student Name=");
        return myObj.nextLine();
    }

    public String collegeRegNo(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a college Register number=");
        return myObj.nextLine();
    }

    public String collegeName(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a college Name=");
        return myObj.nextLine();
    }

    public String courseDetails(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a course details=");
        return myObj.nextLine();
    }

    public int courseStarting(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a course starting year=");
        return myObj.nextInt();
    }

    public int courseEnding(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a course ending year=");
        return myObj.nextInt();
    }

    public double amount(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Loan amount=");
        return myObj.nextDouble();
    }

    public int numberOfEmi(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Number of EMI=");
        return myObj.nextInt();
    }

    public String chooseBank(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("choose the bank=");
        return myObj.nextLine();
    }
}

class details extends bank{

    public double axisBank() {
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Axis Bank Education loan interest rate=");
        double interestRate=myObj.nextDouble();
        return interestRate;
    }

    public double hdfcBank() {
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a HDFC Bank Education loan interest rate=");
        double interestRate1=myObj.nextDouble();
        return interestRate1;
    }

    public double sbiBank() {
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a SBI Bank Education loan interest rate=");
        double interestRate2=myObj.nextDouble();
        return interestRate2;
    }

    public double indianBank() {
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Indian Bank Education loan interest rate=");
        double interestRate3=myObj.nextDouble();
        return interestRate3;
    }
}
public class AbstractMethod {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);

        //Create the object.
        details demo=new details();

        //Student Details
        System.out.println("Student and College Details:");
        String name=demo.studentName();
        String regNo=demo.collegeRegNo();
        String college=demo.collegeName();

        //Choose the Course Details
        int condition=0;
        while(condition != 1){
            try{
                String course=demo.courseDetails();
               switch (course) {
                   case "B.E":
                   case "b.e":
                       int courseDuration=4;
                       System.out.println("B.E Course Duration="+courseDuration+"year");
                       condition=1;
                       break;
                   case "B.SC":
                   case "b.sc":
                       int courseDuration1=3;
                       System.out.println("B.SC Course Duration="+courseDuration1+"year");
                       condition=1;
                       break;
                   case "B.COM":
                   case "b.com":
                       int courseDuration2=3;
                       System.out.println("B.COM Course Duration="+courseDuration2+"year");
                       condition=1;
                       break;
                   case "MBBS":
                   case "mbbs":
                       int courseDuration3=5;
                       System.out.println("MBBS Course Duration="+courseDuration3+"year");
                       condition=1;
                       break;
                   case "CATERING":
                   case "catering":
                       int courseDuration4=2;
                       System.out.println("B.E Course Duration="+courseDuration4+"year");
                       condition=1;
                       break;
                   default:
                       System.out.println("Wrong course is used and check it");
               }
            }catch (Exception e){
                System.out.println("Error");
            }
        }

        //Check the course start year.
        condition=0;
        int starting=0;
        while(condition != 1){
            try{
                starting=demo.courseStarting();
                if(starting>2000 && starting<2022){
                    condition=1;
                }else{
                    System.out.println("Course starting limit is 2000 to 2022");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //Check the course end year.
        condition=0;
        int ending=0;
        while(condition != 1){
            try{
                ending=demo.courseEnding();
                if(ending>2000 && ending<2022){
                    condition=1;
                }else{
                    System.out.println("Course starting limit is 2000 to 2022");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        System.out.println("---------------------------------------------------------------------");

        System.out.println("Bank loan Details:");

        //Check the Loan amount.
        condition=0;
        double loanAmount=0.00d;
        while(condition != 1){
            try{
                loanAmount=demo.amount();
                if(loanAmount>=100000 && loanAmount<=600000){
                    condition=1;
                }else{
                    System.out.println("Loan amount limit is 1 lakhs to 6 lakhs");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //Check the number of year in emi.
        condition=0;
        int emi=0;
        while(condition != 1){
            try{
                emi=demo.numberOfEmi();
                if(emi>=12 && emi<=24){
                    condition=1;
                }else{
                    System.out.println("emi limit is 12 to 24");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        System.out.println("---------------------------------------------------------------------");

        System.out.println("Bank education loan interest rate details ");

        //check the Axis bank interest rate.
        condition=0;
        double axis=0.0d;
        while(condition != 1){
            try{
                axis=demo.axisBank();
                if(axis>10.00 && axis<15.00){
                    condition=1;
                }else{
                    System.out.println("Axis bank education loan limit is 10% to 15%");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //check the HDFC bank interest rate.
        condition=0;
        double hdfc=0.0d;
        while(condition != 1){
            try{
                hdfc=demo.hdfcBank();
                if(hdfc>10.00 && hdfc<15.00){
                    condition=1;
                }else{
                    System.out.println("HDFC bank education loan limit is 10% to 15%");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //check the SBI bank interest rate.
        condition=0;
        double sbi=0.0d;
        while(condition != 1){
            try{
                sbi=demo.sbiBank();
                if(sbi>10.00 && sbi<15.00){
                    condition=1;
                }else{
                    System.out.println("SBI bank education loan limit is 10% to 15%");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //check the Indian bank interest rate.
        condition=0;
        double indian=0.0d;
        while(condition != 1){
            try{
                indian=demo.indianBank();
                if(indian>10.00 && indian<15.00){
                    condition=1;
                }else{
                    System.out.println("Indian bank education loan limit is 10% to 15%");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }
        System.out.println("---------------------------------------------------------------------");

        System.out.println("choose the bank and Loan calculation details");
        condition=0;
        while (condition!=1){
            try{
                String bankLoan=demo.chooseBank();
                switch (bankLoan){
                    case "AXIS":
                    case "axis":
                        double monthEmi=(loanAmount*emi*(axis/100)/100);
                        System.out.println("Bank="+bankLoan);
                        System.out.println("Total Principal amount="+loanAmount);
                        System.out.println("Number of EMI="+emi);
                        System.out.println("Interest Rate="+axis+"%");
                        System.out.println("Month emi amount="+String.format("%.2f",monthEmi));
                        System.out.println("Total EMI amount="+String.format("%.2f",(monthEmi*emi)));
                        condition=1;
                        break;
                    case "HDFC":
                    case "hdfc":
                        double monthEmi1=(loanAmount*emi*(hdfc/100)/100);
                        System.out.println("Bank="+bankLoan);
                        System.out.println("Total Principal amount="+loanAmount);
                        System.out.println("Number of EMI="+emi);
                        System.out.println("Interest Rate="+hdfc+"%");
                        System.out.println("Month emi amount="+String.format("%.2f",monthEmi1));
                        System.out.println("Total EMI amount="+String.format("%.2f",(monthEmi1*emi)));
                        condition=1;
                        break;

                    case "SBI":
                    case "sbi":
                        double monthEmi2=(loanAmount*emi*(sbi/100)/100);
                        System.out.println("Bank="+bankLoan);
                        System.out.println("Total Principal amount="+loanAmount);
                        System.out.println("Number of EMI="+emi);
                        System.out.println("Interest Rate="+sbi+"%");
                        System.out.println("Month emi amount="+String.format("%.2f",monthEmi2));
                        System.out.println("Total EMI amount="+String.format("%.2f",(monthEmi2*emi)));
                        condition=1;
                        break;

                    case "INDIAN":
                    case "indian":
                        double monthEmi3=(loanAmount*emi*(indian/100)/100);
                        System.out.println("Bank="+bankLoan);
                        System.out.println("Total Principal amount="+loanAmount);
                        System.out.println("Number of EMI="+emi);
                        System.out.println("Interest Rate="+indian+"%");
                        System.out.println("Month emi amount="+String.format("%.2f",monthEmi3));
                        System.out.println("Total EMI amount="+String.format("%.2f",(monthEmi3*emi)));
                        condition=1;
                        break;
                    default:
                        System.out.println("Wrong bank is used and check it.");
                        break;
                }
            }catch (Exception e){
                System.out.println("error");
            }
        }
        System.out.println("---------------------------------------------------------------------");
    }
}
