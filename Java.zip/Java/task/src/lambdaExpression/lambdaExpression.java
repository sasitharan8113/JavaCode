package lambdaExpression;

//functional interface
interface MyInterface{
    // abstract method
    double value();
}

public class lambdaExpression {
    public static void main( String[] args ) {

        // declare a reference to MyInterface
        MyInterface ref;

        // lambda expression
        ref = () -> 23.543;

        System.out.println("Lambda expression values = " + ref.value());
    }
}
