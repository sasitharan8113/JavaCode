package FileHandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class FileHandling {
    public static void main(String[] args) throws IOException {
        LocalDateTime date = LocalDateTime.now();
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
        String timeStamp = sdf.format(new Date());
        File directoryPath = new File("D:");
        File fileInput = new File( "file.text"+ timeStamp);
        if (fileInput.createNewFile())
        {
            System.out.println("File created: " + fileInput.getName());
        } else
        {
            System.out.println("File already exists.");
        }
        System.out.println("Output is Successfully printed in the newly created text file");
        PrintStream stream = new PrintStream(fileInput);
        System.out.println("From now on "+fileInput.getAbsolutePath()+" will be my console");
        System.setOut(stream);


        FileWriter myWriter = new FileWriter(fileInput);

        String content[] = directoryPath.list();
        for (int i = 0; i < content.length; i++) {
            myWriter.write("|\n");
            myWriter.write("|__\n");
            myWriter.write(content[i] + "\n");
            System.out.println("|");
            System.out.println("|___");
            System.out.println(content[i]);
            File directoryPath1;

            directoryPath1 = new File("D:" + content[i]);
            String[] content1;
            try {
                content1 = directoryPath1.list();
                for (int j = 0; j < content1.length; j++) {
                    myWriter.write("        |\n");
                    myWriter.write("        |__\n");
                    myWriter.write("         " + content1[j] + "\n");

                    System.out.println("          |");
                    System.out.println("          └── ");
                    System.out.println("           " + content1[j]);
                }

            } catch (Exception e) {

                directoryPath1 = new File("D:" + content[i]);
            }
        }
        myWriter.close();
    }

}
