import java.util.Scanner;
public class Arithmetic {

    public static int add(int a,int b){
        return a+b;
    }

    public static int subtract(int a,int b){
        return a-b;
    }

    public static int multiply(int a, int b){
        return a*b;
    }

    public static int divide(int a,int b){
        return a/b;
    }

    public static int modulus(int a,int b){
        return a%b;
    }

    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int x,y;
        System.out.print("Enter a x value=");
        x=myObj.nextInt();
        System.out.print("Enter a y value=");
        y=myObj.nextInt();

        //Increment
        x++;
        System.out.println("increment values="+x);

        //Decrement
        y--;
        System.out.println("decrement values="+y);

        //Add
        System.out.println("Addition values="+add(x,y));

        //Subtract
        System.out.println("Subtraction values="+subtract(x,y));

        //Multiply
        System.out.println("Multiplication values="+multiply(x,y));

        //Division
        System.out.println("Division values="+divide(x,y));

        //Modulus
        System.out.println("Modulus values="+modulus(x,y));
    }
    int x=28;


}
