import java.util.Scanner;
public class Assignment {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int x;
        System.out.print("Enter a x value=");
        x=myObj.nextInt();
        int x1=x;
        System.out.println(x+=x1);
        System.out.println(x);
        System.out.println(x-=x1);
        System.out.println(x*=x1);
        System.out.println(x^=x1);
        System.out.println(x%=x1);
    }
}
