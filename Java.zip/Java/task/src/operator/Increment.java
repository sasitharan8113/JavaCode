public class Increment{
    public static void main(String[] args) {
        int a=45;
        System.out.println(++a);//46
        System.out.println(++a);//47
        System.out.println(a--);//47
        System.out.println(a--);//46
        System.out.println(--a);//44
        System.out.println(a++ + a++);//89
        System.out.println(a--);//46
        System.out.println(--a);//44
        System.out.println(a++);//44
        System.out.println(a++);//45
        System.out.println(a-- + a++);//91
    }
}
