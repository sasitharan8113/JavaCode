import java.util.Scanner;
public class Logical {
    public static void main(String[] args) {
       Scanner myObj=new Scanner(System.in);
       int x,y,z;
       System.out.print("Enter a x value=");
       x=myObj.nextInt();
       System.out.print("Enter a y value=");
       y=myObj.nextInt();
       System.out.print("Enter a z value=");
       z=myObj.nextInt();
       if(x<y && y<z && x<z){
           System.out.print("logical and");
       } else if (x<y ||y<z ||x<z) {
           System.out.print("logical or");
       }else{
           System.out.print("default");
       }
    }
}
