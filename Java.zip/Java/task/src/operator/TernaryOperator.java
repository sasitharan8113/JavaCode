import java.util.Scanner;
public class TernaryOperator {
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int x,y,z;
        System.out.print("Enter a x value=");
        x=myObj.nextInt();
        System.out.print("Enter a y value=");
        y=myObj.nextInt();
        System.out.print("Enter a z value=");
        z=myObj.nextInt();
        java.lang.String num1="sasi";
        java.lang.String num2="sasi";

        //ternary operator
        java.lang.String sum=(num1!=num2)?"eligible":"not eligible";
        System.out.println("vote is "+sum);

        //Nested ternary operator
        int result=(x<y)?(x<z?x:z):(y<z?y:z);
        System.out.print("Smallest number="+result);
    }
}
