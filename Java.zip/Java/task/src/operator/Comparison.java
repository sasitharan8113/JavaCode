import java.util.Scanner;
public class Comparison {
    public static void main(String[] args){
        Scanner myObj=new Scanner(System.in);
        int x,y;
        System.out.print("Enter a x value=");
        x=myObj.nextInt();
        System.out.print("Enter a y value=");
        y=myObj.nextInt();

        //logical operator

        if(x==y){
            System.out.print("a is equal to b");
        }else if(x<y){
            System.out.print("a is less than b");
        } else if (x>y) {
            System.out.print("a is greater than b");
        }else{
            System.out.print("It is not equal");
        }
    }
}
