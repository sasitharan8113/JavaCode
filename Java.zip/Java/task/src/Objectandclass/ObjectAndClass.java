package Objectandclass;

import java.util.Scanner;

class base1 {

    //Create the leap year number
    public static int leapYear() {
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a leap year=");
        return myObj.nextInt();
    }

    //calculate the leap year

    public static int leapYearResult(int year){
        if(year%4==0){
            System.out.println(year+" is leap year");
        }else{
            System.out.println(year+" is not leap year");
        }
        return year;
    }

    //create the array size
    public static int arrayLimit(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a array size=");
        return myObj.nextInt();
    }

    private int empId;
    private String name;
    private byte age;
    private String location;
    private double salary;

    public void getData(int empId,String name,byte age,String location,double salary){
        this.empId=empId;
        this.name=name;
        this.age=age;
        this.location=location;
        this.salary=salary;
    }

    public void display(){
        System.out.println("Employee ID="+empId);
        System.out.println("Employee name="+name);
        System.out.println("Employee Age="+age);
        System.out.println("Employee location="+location);
        System.out.println("Employee Basic salary="+salary);
    }

    //Employee Details
    public static int employeeId(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a Employee Id=");
        return myObj.nextInt();
    }

    public static java.lang.String employeeName(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a Employee Name=");
        return myObj.nextLine();
    }

    public static byte employeeAge(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a Employee Age=");
        return myObj.nextByte();
    }

    public static String employeeLocation(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a Employee Location=");
        return myObj.nextLine();
    }

    public static double employeeDouble(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a Employee salary=");
        return myObj.nextDouble();
    }
}

class base2 {
    public static String letter(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a character=");
        return myObj.nextLine();
    }

   public static String switchCaseStatement(){
    base2 data=new base2();
    String details=data.letter();
    switch (details){
        case "january":
        case "JANUARY":
            System.out.println("January is first month in calender");
            break;
        case "february":
        case "FEBRUARY":
            System.out.println("February is second month in calender");
            break;
        case "march":
        case "MARCH":
            System.out.println("March is third month in calender");
            break;
        case "april":
        case "APRIL":
            System.out.println("April is fourth month in calender");
            break;
        case "may":
        case "MAY":
            System.out.println("May is Fifth month in calender");
            break;
        case "june":
        case "JUNE":
            System.out.println("June is sixth month in calender");
            break;
        case "july":
        case "JULY":
            System.out.println("July is seventh month in calender");
            break;
        case "august":
        case "AUGUST":
            System.out.println("August is seventh month in calender");
            break;
        case "september":
        case "SEPTEMBER":
            System.out.println("September is seventh month in calender");
            break;
        case "october":
        case "OCTOBER":
            System.out.println("October is seventh month in calender");
            break;
        case "november":
        case "NOVEMBER":
            System.out.println("November is seventh month in calender");
            break;
        case "december":
        case "DECEMBER":
            System.out.println("December is seventh month in calender");
            break;
        default:
            System.out.println("Invalid input");
            details=data.letter();
    }
       return details;
   }
    //static variable
    static int number;
    public static int number() {
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a Static number=");
        return myObj.nextInt();
    }

    //final variable
    static final int variable=22;
    public static void finalVariable() {
        System.out.print(variable);
    }

    //increment method
    public static int increment(){
        base2 data1=new base2();
        int values=data1.number();
        System.out.println("Increment values="+(++values));
        return values;
    }

    //create the decrement method
    public static int decrement(){
        base2 data1=new base2();
        int values1=data1.number();
        System.out.print("Decrement values="+(--values1));
        return values1;
    }
}

public class ObjectAndClass {
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);

        //create the object.
        base1 demo = new base1();

        //check the leap year number
        int condition = 0, year = 0;
        while (condition != 1) {
            try {
                year = demo.leapYear();
                if (year > 0 && year <= 9999) {
                    condition = 1;
                } else {
                    System.out.println("values is greater than 0 and also 4 digit values only used");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        demo.leapYearResult(year);

        System.out.println("-------------------------------------------------------------------------");
        condition=0;
        int limit=0;
        while (condition!=1){
            try{
                limit=demo.arrayLimit();
                if(limit>0 && limit<=6){
                    condition=1;
                }else{
                    System.out.println("values is greater than 0 and less than 6 values only used");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        System.out.println("Enter the array element=");
        double sum=0.0, mean=0.0,sumOfSquares=0.0,meanOfSquares=0.0;
        double arr[]=new double[limit];
        for(int i=0;i<limit;i++){
            arr[i]=myObj.nextDouble();
            sum+=arr[i];
        }
        mean=sum/limit;
        double[] standardDerivation=new double[limit];
        for(int i=0;i<limit;i++){
            standardDerivation[i]=Math.pow((arr[i]-mean),2);
            sumOfSquares+=standardDerivation[i];
        }
        meanOfSquares=sumOfSquares/limit;
        double derivation=Math.sqrt(meanOfSquares);
        System.out.println("Standard derivation="+derivation);

        //check the employee id
        System.out.println("-------------------------------------------------------------------------");
        condition = 0;
        int id = 0;
        while (condition != 1) {
            try {
                id = demo.employeeId();
                if (id > 0 && id <= 100) {
                    condition = 1;
                } else {
                    System.out.println("values is greater than 0 and less than 100 values only used");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        //check the employee name method call
        String name = demo.employeeName();

        //check the employee age
        condition = 0;
        byte age = 0;
        while (condition != 1) {
            try {
                age = demo.employeeAge();
                if (age > 0 && age <= 100) {
                    condition = 1;
                } else {
                    System.out.println("values is greater than 0 and less than 100 values only used");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }

        //check the employee location method call
        String location = demo.employeeLocation();

        //check the employee salary
        condition = 0;
        double salary = 0;
        while (condition != 1) {
            try {
                salary = demo.employeeDouble();
                if (salary > 10000 && salary <= 100000) {
                    condition = 1;
                } else {
                    System.out.println("values is greater than 10000 and less than 100000 values only used");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        demo.getData(id, name, age, location, salary);
        demo.display();

        System.out.println("-------------------------------------------------------------------------");

        //create the object.
        base2 demo1 = new base2();
        condition=0;
        while (condition!=1){
            try{
                String switchCase = demo1.switchCaseStatement();
                String switchCase1=switchCase;
                if(switchCase==switchCase1){
                    condition=1;
                }else{
                    System.out.println("error");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }

        System.out.println("-------------------------------------------------------------------------");

        System.out.println("Display the static variable");
        //check the static variable
        condition = 0;
        while (condition != 1) {
            try {
                int staticNumber = demo1.number();
                if (staticNumber > 0 && staticNumber <= 999999) {
                    condition = 1;
                } else {
                    System.out.println("values is greater than 0 and less than 100000 values only used");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }

        System.out.println("-------------------------------------------------------------------------");

        System.out.println("Display the final variable");
        //final variable
        System.out.print("Enter a final variable=");
        demo1.finalVariable();

        System.out.println("\n-------------------------------------------------------------------------");

        System.out.println("Display the increment method");
        //increment method call
        demo1.increment();

        System.out.println("-------------------------------------------------------------------------");

        System.out.println("Display the decrement method");
        //decrement method call
        demo1.decrement();

        System.out.println("\n-------------------------------------------------------------------------");
    }
}

