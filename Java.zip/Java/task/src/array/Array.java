package array;

import java.util.Scanner;

public class Array {
    public static int size(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a number=");
        return myObj.nextInt();
    }
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int condition=0,limit=0,j,temp=0;
        while(condition!=1){
            try {
                limit = size();
                if (limit>0 && limit<=6){
                    condition = 1;
                }else{
                    System.out.println("values is greater than 0 and also less than 6 only used");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        //Create the array
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("One array to another array copy:");
        int arr[]=new int[limit];
        System.out.println("Enter the array element=");
        for(int i=0;i<arr.length;i++){
            arr[i]=myObj.nextInt();
        }
        System.out.print("Original array=");
        for(int i:arr){
            System.out.print(i+" ");
        }

        //One array element copy to another array
        int arr1[]=new int[arr.length];
        for(int i=0;i<arr1.length;i++){
            arr1[i]=arr[i];
        }
        System.out.print("\ncopy another array=");
        for(int i:arr1){
            System.out.print(i+" ");
        }
        System.out.println("\n-------------------------------------------------------------------------");

        //Ascending order
        System.out.println("Ascending order in array:");
        System.out.print("Ascending order=");
        for(int i=0;i<arr.length;i++){
            for(j=i+1;j<arr.length;j++){
                if(arr[i]>arr[j]){
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        for(int i:arr){
            System.out.print(i+" ");
        }
        System.out.println("\n-------------------------------------------------------------------------");

        System.out.println("Frequency number in array:");
        for (int i = 0; i < arr.length; i++) {
           int count = 1;
            for (j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                } else {
                    break;
                }
            }
            i = j - 1;
            if (count >= 1) {
                System.out.println("The element is " + arr[i] + " and its frequency is " + count);
            }
        }
        System.out.println("-------------------------------------------------------------------------");

        //Descending order
        System.out.println("Descending order in array:");
        System.out.print("Descending order=");
        for(int i=0;i<arr.length;i++){
            for(j=i+1;j<arr.length;j++){
                if(arr[i]<arr[j]){
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        for(int i:arr){
            System.out.print(i+" ");
        }
        System.out.println("\n-------------------------------------------------------------------------");

        //Repeating number in array
        System.out.println("Repeat number in array:");
        int check = 0;
        System.out.print("Repeat element=");
        for (int i = 0; i < arr.length; i++) {
            for (j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    System.out.print(arr[j]+" ");
                    check=1;
                    break;
                }
            }
        }
        if (check == 0) {
            System.out.println("No repeat element in array");
        }
        System.out.println("\n-------------------------------------------------------------------------");




    }
}
