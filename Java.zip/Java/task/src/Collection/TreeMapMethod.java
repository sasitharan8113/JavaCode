package Collection;

import java.util.Map;
import java.util.TreeMap;

class TreeMapMethod {
    public static void display(){
        System.out.println("TreeMap Method:\n");
        TreeMap<Integer,String>details=new TreeMap<>();
        details.put(1,"Sasitharan");
        details.put(4,"priya");
        details.put(2,"preethi");
        details.put(3,"sethuraj");

        System.out.println("Display the treemap input:");
        for(Map.Entry m:details.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }

        System.out.println("\nDescending TreeMap="+details.descendingMap());

        System.out.println("\nHeadMap="+details.headMap(3,true));

        System.out.println("\nTailMap: "+details.tailMap(2,true));

        System.out.println("\nSubMap: "+details.subMap(1, false, 2, true));

        System.out.println("\nKeys: " + details.keySet());

        System.out.println("\nValues: " +details.values());

        details.replace(1,"hello");
        System.out.println("\nreplace value="+details);

        System.out.println("\nTreemap size="+details.size());

        System.out.println("\nfirst key in treemap="+details.firstKey());

        System.out.println("\nlast key in treemap="+details.lastKey());

        System.out.println("\nGet method in treemap="+details.get(3));

        details.remove(4);
        System.out.println("\nRemove method in treemap="+details);

        details.clear();
        System.out.println("\nClear method="+details);

        System.out.println("\n-------------------------------------------------------------------------------");
    }
}
