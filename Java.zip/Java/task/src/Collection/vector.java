package Collection;

import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;

class vector {

    public static void display(){
        System.out.println("Vector class in list Method:\n");
        Vector<String>details=new Vector<>();

        //add method.
        details.add("hello");
        details.add("world");
        details.add("bye");
        details.addElement("hi");
        details.addElement("welcome");

        //for each loop.
        System.out.print("Add Method=");
        for (String i:details){
            System.out.print(i+" ");
        }

        System.out.println();

        Vector<String>details1= new Vector<>();
        details1.add("morning");
        details1.add("evening");
        details1.add("night");

        System.out.print("\nAdd second element=");
        for (String j:details1){
            System.out.print(j+" ");
        }

        details.addAll(0,details1);

        System.out.println();

        System.out.print("\naddAll method=");
        for (String s:details){
            System.out.print(s+" ");
        }

        System.out.println();

        System.out.print("\nset method:");
        details.set(3,"sasi");

        for (String s:details){
            System.out.print(s+" ");
        }

        System.out.println("\n");

        details.remove(2);

        System.out.println("Remove Method=");
        for (String a:details){
            System.out.print(a+" ");
        }

        System.out.println("\n");

        System.out.println("Vector empty = " +details.isEmpty()+"\n");

        Collections.sort(details);

        System.out.print("sort Method=");
        for (String m:details){
            System.out.print(m+" ");
        }

        System.out.println("\n");

        System.out.print("Iterator Method=");
        Iterator<String> itr = details.iterator();
        while(itr.hasNext()){
            System.out.print(itr.next()+" ");
        }

        System.out.println("Get Method="+details.get(4)+"\n");

        System.out.println("vector size="+details.size());

        System.out.println();

        details.setSize(11);
        System.out.println("setSize Method=");
        for (String k:details){
            System.out.println(k);
        }

        System.out.println();

        details.removeAll(details);
        System.out.println("RemoveAll Method="+details.size());

        System.out.print("\n----------------------------------------------------------------");
    }
}
