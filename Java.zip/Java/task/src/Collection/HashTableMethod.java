package Collection;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;

class HashTableMethod {
    public static void display(){
        System.out.println("HashTable Method:");
        Hashtable<String,Integer>details=new Hashtable<>();
        details.put("sasi",1);
        details.put("priya",2);
        details.put("Sathish",3);
        details.put("preethi",4);

        System.out.print("\nDisplay the hashtable input=");
        for (Map.Entry i:details.entrySet()){
            System.out.print(i+" ");
        }

        System.out.println("\n\nGet Method in hashTable="+details.get("priya"));

        details.putIfAbsent("Gaurav",4);
        System.out.println("\nAdd the element in hashTable="+details);

        System.out.println("\nHashTable size="+details.size());

        System.out.println("\nRemove the element in hashTable="+details.remove("Gaurav"));
        System.out.println("Remove the element in display the balance element=");
        for (Map.Entry j:details.entrySet()){
            System.out.print(j+" ");
        }

        Enumeration enu = details.keys();
        System.out.println("\n\nKey element in hashtable:");
        while (enu.hasMoreElements()) {
            System.out.println(enu.nextElement());
        }
        details.clear();
        System.out.println("\nClear the hashtable method ="+details);

        System.out.println("\n------------------------------------------------------------------------------");
    }
}
