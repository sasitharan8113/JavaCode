package Collection;

public class Collection{
    public static void main(String[] args) {

        //ArrayList called.
        ArrayListCollection obj1=new ArrayListCollection();
        obj1.display();

        //vector called.
        vector obj2=new vector();
        obj2.display();

        //HashSet called
        HashSetMethod obj3=new HashSetMethod();
        obj3.display();

        //TreeSet called
        TreeSetMethod obj4=new TreeSetMethod();
        obj4.display();

        //HashMap called
        HashMapMethod obj5=new HashMapMethod();
        obj5.display();

        //TreeMap called
        TreeMapMethod obj6=new TreeMapMethod();
        obj6.display();

        //HashTable called
        HashTableMethod obj7=new HashTableMethod();
        obj7.display();
    }
}
