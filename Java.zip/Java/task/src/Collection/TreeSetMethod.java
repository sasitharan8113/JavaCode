package Collection;

import java.util.Iterator;
import java.util.TreeSet;

class TreeSetMethod {
    public static void display(){
        System.out.print("\nTreeSet Method:\n\n");
        TreeSet<Integer> details=new TreeSet<>();
        details.add(23);
        details.add(12);
        details.add(45);
        details.add(123);

        System.out.print("Add Method in TreeSet=");
        for (int i:details){
            System.out.print(i+" ");
        }

        int value = details.ceiling(53);
        System.out.println("\n\nCeiling value for 53: "+ value);

        TreeSet<Integer> details1=new TreeSet<>();
        details1.add(32);
        details1.add(122);
        details1.add(450);
        details1.add(17);

        System.out.print("\nadd one Method in TreeSet=");
        for (int j:details1){
            System.out.print(j+" ");
        }

        System.out.print("\n\naddAll Method in TreeSet=");
        details.addAll(details1);
        for (int m:details){
            System.out.print(m+" ");
        }

        System.out.print("\n\nDescendingIterator=");
        Iterator iterator=details.descendingIterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println("\n\nfloor value of 78 in set: " +details.floor(78));

        System.out.println("\nRemoved element using pollFirst() : " +details.pollFirst());
        System.out.println("After removing element from TreeSet: " +details);

        System.out.println("\nRemoved element using pollLast() : " +details.pollLast());
        System.out.println("After removing element from TreeSet: " +details);

        System.out.print("\nTreeSet size="+details.size());

        System.out.println("\n\nFirst lowest element: "+details.first());

        System.out.println("\nFirst biggest element: "+details.last()+"\n");

        details.clear();

        System.out.print("-----------------------------------------------------------------------------");
    }
}
