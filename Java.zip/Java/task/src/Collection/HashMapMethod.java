package Collection;

import java.util.HashMap;
import java.util.Map;

class HashMapMethod {

    public void display(){
        System.out.println("\nHashMap Method:"+"\n");
        HashMap<Integer,String>details=new HashMap<>();
        details.put(1,"sasi");
        details.put(13,"mathan");
        details.put(26,"priya");
        details.put(45,"preethi");

        System.out.println("Display the HashMap details:");
        for (Map.Entry i:details.entrySet()){
        System.out.println(i);
        }

        details.putIfAbsent(103,"ajith");
        System.out.println("\nputIfAbsent method ");
        for(Map.Entry m:details.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }

        HashMap<Integer,String> details1=new HashMap<>();
        details1.put(11,"Ravi");

        details1.putAll(details);
        System.out.println("\nputAll method ");
        for(Map.Entry m:details1.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }

        System.out.print("\nRemove the Key:\n");
        details.remove(1,"sasi");
        System.out.println("Updated list of elements: "+details);

        System.out.println("\nHashMap size="+details.size());

        System.out.println("\nContains method:");
        System.out.println("Contains key in hashmap="+details.containsKey(26));

        System.out.println("contains value in hashmap="+details.containsValue("sasi"));

        details.replace(103,"hello");
        System.out.println("\nreplace value=" + details.toString()+"\n");

        System.out.println("-------------------------------------------------------------------------------");
    }
}
