package Collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class ArrayListCollection {
    static  int num;
    public static int checkNum(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a access arraylist index number=");
        return num=myObj.nextInt();
    }

    public static int checkNum1(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a change Index in arraylist=");
        return num=myObj.nextInt();
    }

    public static int value(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a change the value=");
        return num=myObj.nextInt();
    }
    public static void display() {
        System.out.println("ArrayList Method in collections:"+"\n");
        Scanner myObj = new Scanner(System.in);
        ArrayList<Integer> method1 = new ArrayList<Integer>();
        method1.add(23);
        method1.add(24);
        method1.add(12);
        method1.add(46);
        System.out.println("ArrayList method="+method1);
        System.out.println();

        int condition=0;
        int callNumber=0;
        while (condition!=1){
            try{
               callNumber=checkNum();
                if(callNumber>0 && callNumber<=method1.size()){
                    condition=1;
                }else{
                    System.out.println("Access item limit is over and check it.");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        System.out.println("Access Item in arraylist="+method1.get(callNumber));
        System.out.println();

        condition=0;
        int callNumber1=0;
        while (condition!=1){
            try{
                callNumber1=checkNum1();
                if(callNumber1>0 && callNumber1<=method1.size()){
                    condition=1;
                }else{
                    System.out.println("Change item limit is over and check it.");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        condition=0;
        int valueItem=0;
        while (condition!=1){
            try{
                valueItem=checkNum1();
                if(valueItem>0 && valueItem<=9999){
                    condition=1;
                }else{
                    System.out.println("Change item limit is over and check it.");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }
        method1.set(callNumber1,valueItem);
        System.out.println();
        System.out.print("change the value in arraylist=");
        for(int i:method1){
            System.out.print(i+" ");
        }
        System.out.println("\n");

        method1.remove(callNumber1);

        System.out.print("show the remove number in arraylist=");
        for(int i:method1){
            System.out.print(i+" ");
        }

        System.out.println();

        Collections.sort(method1);
        System.out.print("\nSort method in arraylist=");
        for (int i:method1){
            System.out.print(i+" ");
        }
        System.out.println("\n-----------------------------------------------------------------");
    }
}
