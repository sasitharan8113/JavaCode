package Collection;

import java.util.HashSet;
import java.util.Iterator;

class HashSetMethod {
    public static void display(){
        System.out.println("\nHashSet Method:\n");
        HashSet<String>details=new HashSet<>();
        details.add("sasi");
        details.add("arun");
        details.add("vijay");
        details.add("mathan");
        details.add("sasi");

        System.out.print("Add Method in HashSet:");
        for (String i:details){
            System.out.print(i+" ");
        }

        System.out.println("\n\ndetails Size="+details.size());

        System.out.println("\ncontain method="+details.contains("priya"));

        System.out.print("\nIterator Method=");
        Iterator<String> itr=details.iterator();
        while(itr.hasNext()){
            System.out.print(itr.next()+" ");
        }

        System.out.print("\n\nCloning Method:");
        HashSet<String> clonedSet = new HashSet<String>();
        clonedSet = (HashSet)details.clone();
        System.out.println("\nThe new clone set elements: " + clonedSet);

        System.out.print("\nRemove Method=");
        details.remove("sasi");
        for (String k:details){
            System.out.print(k+" ");
        }
        System.out.println("\n\nIs the set empty: "+details.isEmpty());
        details.clear();
        System.out.println("\nIs the set empty: "+details.isEmpty());

        System.out.print("\n------------------------------------------------------------------------");
    }
}
