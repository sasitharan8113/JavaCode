package Interface;

import java.util.Scanner;

interface consumer{

    //static methods
    static void display(){
        System.out.println("Consumer Details:");
    }

   //default by abstract or public considered.
    String name();
    public String houseNumber();
    abstract long ebNumber();
    String place();
    String district();
}

interface eb{
    default void display1(){
        System.out.println("EB Details:");
    }

    abstract String building();
    int unit();
}

class details implements consumer,eb{
   public String name(){
       Scanner myObj=new Scanner(System.in);
       System.out.print("Enter a consumer name=");
       return myObj.nextLine();
   }

   public String houseNumber(){
       Scanner myObj=new Scanner(System.in);
       System.out.print("Enter a consumer house number=");
       return myObj.nextLine();
   }

   public long ebNumber(){
       Scanner myObj=new Scanner(System.in);
       System.out.print("Enter a consumer EB Number=");
       return myObj.nextLong();
   }

    public String place(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a consumer place=");
        return myObj.nextLine();
    }

    public String district(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a consumer district=");
        return myObj.nextLine();
    }

    public String building(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Type of consumer=");
        return myObj.nextLine();
    }

    public int unit(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a consumer use unit=");
        return myObj.nextInt();
    }

}

public class Interface {
    public static void main(String[] args) {
        //Create the object.
        details customer=new details();

        consumer.display();

        String consumerName=customer.name();

        String consumerHouseNumber=customer.houseNumber();

        int condition=0;
        long consumerEbNumber=0l;
        while(condition !=1){
            try {
                consumerEbNumber=customer.ebNumber();
                if(consumerEbNumber>010000000000 && consumerEbNumber<=999999999999l){
                    condition=1;
                }else{
                    System.out.println("EB number limit 12 digit.");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }
        String consumerPlace=customer.place();

        String consumerDistrict=customer.district();

        System.out.println("------------------------------------------------------------------");

        customer.display1();

//        String typeOfBuilding=customer.building();

        condition=0;
        int ebUnit=0;
        while(condition !=1){
            try {
                ebUnit=customer.unit();
                if(ebUnit>000000000000 && ebUnit<=999999999999l){
                    condition=1;
                }else{
                    System.out.println("EB number limit 12 digit.");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        System.out.println("------------------------------------------------------------------");

        condition=0;
        while (condition!=1) {
            try {
               String typeOfBuilding=customer.building();
                switch (typeOfBuilding) {
                    case "residential":
                    case "RESIDENTIAL":
                        if (ebUnit > 100 && ebUnit < 200) {
                            double unit1 = (ebUnit - 100) * 2.25;
                            System.out.println("Total EB Amount=" + unit1);
                        } else if (ebUnit > 100 && ebUnit < 500) {
                            int unit2 = ebUnit - 100;
                            double unit3 = ((100 * 2.25) + (200 * 4.5) + ((unit2 - 300) * 6));
                            System.out.println("Total EB Amount=" + unit3);
                        } else if (ebUnit > 100 && ebUnit < 1000) {
                            int unit4 = ebUnit - 100;
                            double unit5 = (100 * 2.25) + (100 * 4.5) + (100 * 6) + ((unit4 - 300) * 7.5);
                            System.out.println("Total EB Amount=" + unit5);
                        } else {
                            System.out.println("EB Amount is free");
                        }
                        condition = 1;
                        break;
                    case "commerical":
                    case "COMMERICAL":
                        if (ebUnit > 100 && ebUnit < 200) {
                            double unit1 = ebUnit * 3;
                            System.out.println("Total EB Amount=" + unit1);
                        } else if (ebUnit > 100 && ebUnit < 500) {
                            double unit3 = (100 * 3) + (200 * 6) + ((ebUnit - 300) * 7);
                            System.out.println("Total EB Amount=" + unit3);
                        } else if (ebUnit > 100 && ebUnit < 1000) {
                            double unit5 = (100 * 2.3) + (100 * 6) + (100 * 9) + ((ebUnit - 300) * 11);
                            System.out.println("Total EB Amount=" + unit5);
                        } else {
                            System.out.println("EB Amount is free");
                        }
                        condition = 1;
                        break;

                    default:
                        System.out.println("Wrong building is used and check it");
                        break;
                }
            }catch (Exception e){
                System.out.println(e);
            }
        }
        System.out.println("------------------------------------------------------------------");
    }
}
