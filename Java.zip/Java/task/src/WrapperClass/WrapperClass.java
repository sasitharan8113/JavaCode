package WrapperClass;

import java.util.Scanner;

public class WrapperClass {

    public static byte num(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Byte number=");
        return myObj.nextByte();
    }
    public static short num1(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Short number=");
        return myObj.nextShort();
    }
    public static char num2(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a char value=");
        return myObj.next().charAt(0);
    }
    public static int value(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Integer number=");
        return myObj.nextInt();
    }

    public static long num3(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a long number=");
        return myObj.nextLong();
    }

    public static float num4(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a float number=");
        return myObj.nextFloat();
    }

    public static double num5(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a double number=");
        return myObj.nextDouble();
    }

    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int condition=0;
        byte checkValue1=0;
        while(condition != 1){
            try{
                checkValue1=num();
                if(checkValue1>0 && checkValue1<=160){
                    condition=1;
                }else{
                    System.out.println("value limit is 1 to 160");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition=0;
        Short checkValue2=0;
        while(condition != 1){
            try{
                checkValue2=num1();
                if(checkValue2>0 && checkValue2<=32000){
                    condition=1;
                }else{
                    System.out.println("value limit is 1 to 32000");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition=0;
        char checkValue3=0;
        while(condition != 1){
            try{
                checkValue3=num2();
                if(checkValue3>0 && checkValue3<=126){
                    condition=1;
                }else{
                    System.out.println("character value limit is 1 to 126");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition=0;
        int checkValue=0;
        while(condition != 1){
            try{
                checkValue=value();
                if(checkValue>0 && checkValue<=9999){
                    condition=1;
                }else{
                    System.out.println("value limit is 1 to 9999");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition=0;
        long checkValue4=0;
        while(condition != 1){
            try{
                checkValue4=num3();
                if(checkValue4>0 && checkValue4<=99999999){
                    condition=1;
                }else{
                    System.out.println("value limit is 1 to 9999");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition=0;
        float checkValue5=0.0f;
        while(condition != 1){
            try{
                checkValue5=num4();
                if(checkValue5>0.0f && checkValue5<=99999999.99f){
                    condition=1;
                }else{
                    System.out.println("value limit is 1 to 9999999");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition=0;
        double checkValue6=0.00d;
        while(condition != 1){
            try{
                checkValue6=num5();
                if(checkValue6>0.0d && checkValue6<=99999999.99d){
                    condition=1;
                }else{
                    System.out.println("value limit is 1 to 9999999");
                }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and check it");
            }
        }

        System.out.println("------------------------------------------------------------------------");

        //primitive datatype convert to wrapper class
        System.out.println("Wrapper class:");
        //byte to Byte
        Byte byteObj=Byte.valueOf(checkValue1);

        //short to Short
        Short shortObj=Short.valueOf(checkValue2);

        //char to Character
        Character charObj=Character.valueOf(checkValue3);

        //int to Integer
        Integer intObj =Integer.valueOf(checkValue);

        //long to Long
        Long longObj=Long.valueOf(checkValue4);

        //float to Float
        Float floatObj=Float.valueOf(checkValue5);

        //double to Double
        Double doubleObj=Double.valueOf(checkValue6);

        System.out.println("Byte value in wrapper class="+byteObj);
        System.out.println("Short value in wrapper class="+shortObj);
        System.out.println("Integer value in wrapper class="+intObj);
        System.out.println("Character value in wrapper class="+charObj);
        System.out.println("Long value in wrapper class="+longObj);
        System.out.println("float value in wrapper class="+floatObj);
        System.out.println("double value in wrapper class="+doubleObj);

        System.out.println("------------------------------------------------------------------------");

        System.out.println("Auto Boxing:");
        Byte x1=checkValue1;
        Short x2=checkValue2;
        Character x3=checkValue3;
        Integer x4=checkValue;
        Long x5=checkValue4;
        Float x6=checkValue5;
        Double x7=checkValue6;

        System.out.println("Byte value in Auto Boxing="+x1);
        System.out.println("Short value in Auto Boxing="+x2);
        System.out.println("Integer value in Auto Boxing="+x3);
        System.out.println("Character value in Auto Boxing="+x4);
        System.out.println("Long value in Auto Boxing="+x5);
        System.out.println("float value in Auto Boxing="+x6);
        System.out.println("double value in Auto Boxing="+x7);

        System.out.println("------------------------------------------------------------------------");

        byte y1=checkValue1;
        short y2=checkValue2;
        char y3=checkValue3;
        int y4=checkValue;
        long y5=checkValue4;
        float y6=checkValue5;
        double y7=checkValue6;

        System.out.println("Byte value in unboxing="+y1);
        System.out.println("Short value in unboxing="+y2);
        System.out.println("Integer value in unboxing="+y3);
        System.out.println("Character value in unboxing="+y4);
        System.out.println("Long value in unboxing="+y5);
        System.out.println("float value in unboxing="+y6);
        System.out.println("double value in unboxing="+y7);

        System.out.println("------------------------------------------------------------------------");
    }
}
