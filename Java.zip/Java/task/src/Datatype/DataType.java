public class DataType {
    //Datatype of Default value
    byte b;
    static short c;
    static int a;

    static long d;
    static char e;
    static float i;

    double j;

    boolean k;

    public static void main(String[] args) {
        System.out.println(a);
        DataType auto=new DataType();
        System.out.println(auto.b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(i);
        System.out.println(auto.j);
        System.out.println(auto.k);

        //Datatype value initial

        byte num1=20;
        System.out.println(num1);
        short num2=2022;
        System.out.println(num2);
        int num3=-20229865;
        System.out.println(num3);
        long num4=2022998065;
        System.out.println(num4);
        char num5=65;
        System.out.println(num5);
        float num6=5.67f;
        System.out.println(num6);
        double num7=-8733.9d;
        System.out.println(num7);
    }
}
