package TypeCasting;

import java.util.Scanner;

public class TypeCasting {

    public static byte num1(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a num1 values=");
        return myObj.nextByte();
    }

    public static Double num2(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a num2 values=");
        return myObj.nextDouble();
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        int condition = 0;
        byte x = 0;
        while (condition != 1) {
            try {
                x = num1();
                if (x > 0 && x < 9999) {
                    condition = 1;
                } else {
                    System.out.println("x value limit is 0 to 9999");
                }
            } catch (Exception e) {
                System.out.println("Wrong Datatype and correct it");
            }
        }

        condition = 0;
        double y = 0.0d;
        while (condition != 1) {
            try {
                y = num2();
                if (y > 0 && y < 9999) {
                    condition = 1;
                } else {
                    System.out.println("x value limit is 0 to 9999");
                }
            } catch (Exception e) {
                System.out.println("Wrong Datatype and correct it");
            }
        }
        System.out.println("--------------------------------------------------------");

        System.out.println("Narrowing Casting:");
        System.out.println("double number="+y);
        float y1 = ((float)y);
        System.out.println("Convert the double to float=" + (y1));
        long y2= (long) y1;
        System.out.println("Convert the float to long=" + (y2));
        int y3= (int) y2;
        System.out.println("Convert the long to int=" + (y3));
        char y4= (char) y3;
        System.out.println("Convert the int to char=" + (y4));
        short y5= (short) y4;
        System.out.println("Convert the char to short=" + (y5));
        byte y6= (byte) y5;
        System.out.println("Convert the short to int=" + (y6));

        System.out.println("--------------------------------------------------------");

        System.out.println("Widening Casting:");
        System.out.println("byte number="+x);
        short x1=x;
        System.out.println("convert the byte to short="+x1);
        int x2=x1;
        System.out.println("convert the short to int="+x2);
        long x3=x2;
        System.out.println("convert the short to long="+x3);
        float x4=x3;
        System.out.println("convert the long to float="+x4);
        double x5=x4;
        System.out.println("convert the float to double="+x5);

        System.out.println("--------------------------------------------------------");
    }
}
