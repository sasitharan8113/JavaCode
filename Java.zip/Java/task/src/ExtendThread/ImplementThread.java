package ExtendThread;

import java.util.Scanner;

class table implements Runnable{
    public void run(){
        Scanner myObj=new Scanner(System.in);
        System.out.println("Matrix multiplication table in implements runnable.");
        System.out.print("Enter a size=");
        int num= myObj.nextInt();
        for(int i=1;i<=num;i++){
            System.out.println(i+"*"+num+"="+i*num);
            try {
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println("error time sleep method");
            }
        }
    }
}

public class ImplementThread {
    public static void main(String[] args) {
        table s1=new table();
        Thread s2=new Thread(s1);
        Thread s3=new Thread(s1);
        s2.run();
        s3.run();
        try {
            s2.join();
        } catch (Exception e) {
           System.out.println(e);
        }
        System.out.println("multiplication table is completed.");
    }
}
