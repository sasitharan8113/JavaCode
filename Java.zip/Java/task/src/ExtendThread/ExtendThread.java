package ExtendThread;

import java.util.Scanner;

class matrixTable extends Thread{
    int num=6;
    public void run(){
        Scanner myObj=new Scanner(System.in);
        System.out.println("Matrix Multiplication in extend thread:");
        System.out.print("Enter a size=");
        int num=myObj.nextInt();
        for(int i=1;i<=num;i++){
            System.out.println(i+"*"+num+"="+i*num);
            try{
                Thread.sleep(2000);
            }catch (Exception e){
                System.out.println("Error sleep time.");
            }
        }
    }
}
public class ExtendThread {
    public static void main(String[] args) throws InterruptedException {
        matrixTable m=new matrixTable();
        m.start();
        if(m.isAlive()){
            System.out.println("still executed.");
        }else{
            System.out.println("It is not executed.");
        }
        m.join();
        System.out.println("thread running...");
    }
}
