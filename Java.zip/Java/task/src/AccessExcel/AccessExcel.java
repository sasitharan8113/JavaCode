package AccessExcel;


import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class AccessExcel {

    public static int remove(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a remove row number=");
        return myObj.nextInt();
    }

    public static int num(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a RegNo=");
        return myObj.nextInt();
    }

    public static int size(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a index position in column excel file=");
        return myObj.nextInt();
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner myObj = new Scanner(System.in);
        FileInputStream inputStream = new FileInputStream(new File("D:\\Java\\task\\src\\AccessExcel\\details.xlsx"));

        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet firstSheet = workbook.getSheetAt(0);

        //Display the Excel table.
        System.out.println("Display the Excel table:");
        FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
        Date myDate = new Date();
        for (Row row : firstSheet) {
            for (Cell cell : row) {
                switch (formulaEvaluator.evaluateInCell(cell).getCellType()) {
                    case Cell.CELL_TYPE_NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell))
                        {
                            SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
                            String value = format.format(cell.getDateCellValue());
                            System.out.print(value + "\t\t");
                        } else
                        {
                            double numericCellValue = cell.getNumericCellValue();
                            int i =(int) numericCellValue;
                            System.out.print(i + "\t\t");

                        }
                        break;
                    case Cell.CELL_TYPE_STRING:
                        System.out.print(cell.getStringCellValue()+"\t");
                        break;
                }
            }
            System.out.println();
        }

        System.out.println("-------------------------------------------------------------------------------");
        //Display the particular row.
        System.out.println("Display the particular row:");
        int condition = 0;
        int num1=0;
        while (condition != 1) {
            try {
                num1 = num();
                if(num1>0 && num1<=3){
                    condition=1;
                }else{
                    System.out.println("Row number is 3 only.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        Row row2=firstSheet.getRow(num1);
        System.out.println("RegNo\t"+"Name\t\t"+"DateOfBirth\t\t"+"Mark");
        FormulaEvaluator formulaEvaluator1 = workbook.getCreationHelper().createFormulaEvaluator();
        for (Cell row : row2) {
                switch (formulaEvaluator1.evaluateInCell(row).getCellType()) {
                    case Cell.CELL_TYPE_NUMERIC:
                    if (DateUtil.isCellDateFormatted(row))
                    {
                        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
                        String value = format.format(row.getDateCellValue());
                        System.out.print(value + "\t\t");
                    } else
                    {
                        double numericCellValue = row.getNumericCellValue();
                        int i =(int) numericCellValue;
                        System.out.print(i + "\t\t");

                    }
                        break;
                    case Cell.CELL_TYPE_STRING:
                        System.out.print(row.getStringCellValue() + "\t\t");
                        break;
                }
            System.out.print("");
        }

        System.out.println("\n-------------------------------------------------------------------------------");
        condition=0;
        int columnIndex=0;
        while (condition!=1){
            try{
               columnIndex=size();
               if(columnIndex>=0 && columnIndex<=5){
                   condition=1;
               }else{
                   System.out.println("size limit is 0 to 3.");
               }
            }catch (Exception e){
                System.out.println("Wrong datatype is used and change it.");
            }
        }
        for (int i = 0; i <=4; i++) {
            Row row = firstSheet.getRow(i);
            if (row != null) {
                Cell cell = row.getCell(columnIndex);
                System.out.println(cell);
            }
        }
        System.out.println("-------------------------------------------------------------------------------");

        //Remove the row in Excel Sheet
        System.out.println("Remove the row in Excel Table");
        condition = 0;
        int rowNum = 0;
        while (condition != 1) {
            try {
                rowNum = remove();
                if(rowNum>0 && rowNum<=4){
                    condition=1;
                }else{
                    System.out.println("Row number is 3 only.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }
        int totalRows = firstSheet.getLastRowNum();

        firstSheet.shiftRows(rowNum + 1, totalRows, -1);

        FormulaEvaluator formulaEvaluator2 = workbook.getCreationHelper().createFormulaEvaluator();
        for (Row row : firstSheet) {
            for (Cell cell : row) {
                switch (formulaEvaluator2.evaluateInCell(cell).getCellType()) {
                    case Cell.CELL_TYPE_NUMERIC:
                    if (DateUtil.isCellDateFormatted(cell))
                    {
                        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
                        String value = format.format(cell.getDateCellValue());
                        System.out.print(value + "\t\t");
                    } else
                    {
                        double numericCellValue = cell.getNumericCellValue();
                        int i =(int) numericCellValue;
                        System.out.print(i + "\t\t");

                    }
                        break;
                    case Cell.CELL_TYPE_STRING:
                        System.out.print(cell.getStringCellValue() + "\t\t");
                        break;
                }
            }
            System.out.println();
        }
        System.out.println("-------------------------------------------------------------------------------");
        FileOutputStream out=new FileOutputStream("D:\\Java\\task\\src\\AccessExcel\\details.xlsx");
        workbook.write(out);
    }
}