package StringTask;

import java.util.Scanner;

public class StringTask {

    public static int num1(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a num1=");
        return myObj.nextInt();
    }

    public static int num2(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a num2=");
        return myObj.nextInt();
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        System.out.print("Enter a string input=");
        String str = myObj.nextLine();

        System.out.println("--------------------------------------------------------------------------");
        int condition = 0;
        int startIndex = 0;
        while (condition != 1) {
            try {
                startIndex = num1();
                if (startIndex >= 0 && startIndex <= str.length()) {
                    condition = 1;
                } else {
                    System.out.println("startIndex limit is 0 and maximum is str.length.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        condition = 0;
        int endIndex = 0;
        while (condition != 1) {
            try {
                endIndex = num2();
                if (endIndex >= 0 && endIndex <= str.length()) {
                    condition = 1;
                } else {
                    System.out.println("endIndex limit is 0 and maximum is str.length.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //Substring
        System.out.print("String SubString method:");
        System.out.println(str.substring(startIndex, endIndex));

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("IndexOf method:");
        System.out.print("Enter a string input=");
        String value = myObj.nextLine();
        System.out.println((str.indexOf(value)));

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("String replace method:");

        System.out.print("Enter a choose input=");
        char str1 = myObj.next().charAt(0);

        char str2 = 0;
        try {
            System.out.print("Enter a replace input=");
            str2 = myObj.next().charAt(0);
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("String replace=" + str.replace(str1, str2));

        System.out.println("--------------------------------------------------------------------------");
        System.out.print("Enter a choose input=");
        String chooseStr = myObj.next();

        System.out.print("Enter a replaceAll input=");
        String replaceStr = myObj.next();

        System.out.println("String replace=" + str.replaceAll(chooseStr, replaceStr));

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("String length Method=" + str.length());

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("String Concatenation Method:");
        System.out.print("Enter a string input=");
        String str4 = myObj.next();
        System.out.println("String Concatenation=" + str.concat(" " + str4));

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("Compare two Strings:");
        boolean compareToString = str.equals(str4);
        System.out.println("compare to two string=" + compareToString);

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("Join method:");
        String joinedStr = String.join("/", str, "hello");
        System.out.println("Joined string Method=" + joinedStr);

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("String Split method:");
        String[] result = str.split(" ");

        System.out.print("result = ");
        for (String str5 : result) {
            System.out.print(str5 + ",");
        }
        System.out.print("\n");

        System.out.println("--------------------------------------------------------------------------");

        String upperCase = str.toUpperCase();
        System.out.println("uppercase method=" + upperCase);

        System.out.println("--------------------------------------------------------------------------");

        String lowerCase = upperCase.toLowerCase();
        System.out.println("LowerCase Method=" + lowerCase);

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("Count Vowels:");
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U') {
                count++;
            }
        }
        System.out.println("Vowels count in string=" + count);

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("Uppercase character in a string:");
        for (int i = 0; i < str.length(); i++) {
            if (Character.isUpperCase(str.charAt(i))) {
                System.out.print(str.charAt(i) + " ");
            } else {
                System.out.print("No uppercase character in string.");
                break;
            }
        }

        System.out.println("\n--------------------------------------------------------------------------");

        System.out.println("Lowercase character in a string:");
        for (int i = 0; i < str.length(); i++) {
            if (Character.isLowerCase(str.charAt(i))) {
                System.out.print(str.charAt(i) + " ");
            }
        }
        System.out.println("\n--------------------------------------------------------------------------");

        System.out.println("Enter a character search method:");
        System.out.print("Enter a character=");
        char search = myObj.next().charAt(0);

        count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == search) {
                count++;
            }
        }
        System.out.println("The Character '" + search + "' appears " + count + " times.");

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("Count of white space:");

        int i = 0;
        int space1 = 0;
        while (i < str.length()) {
            char ch = str.charAt(i);
            if (ch == ' ') {
                space1++;
            }
            i++;
        }
        System.out.println("Total white space : " + space1);

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("contains Method:");
        System.out.println(str.contains("sasi"));

        System.out.println("--------------------------------------------------------------------------");

        System.out.println("Char Array elements:");
        char[] ch = str.toCharArray();
        for (i = 0; i < ch.length; i++) {
            System.out.print(ch[i] + " ");
        }

        System.out.println("\n--------------------------------------------------------------------------");

        System.out.println("Trim method:");
        System.out.println(str.trim());

        System.out.println("\n--------------------------------------------------------------------------");
    }
}
