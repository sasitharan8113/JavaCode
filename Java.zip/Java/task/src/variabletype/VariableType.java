import java.util.Scanner;
public class VariableType {

    //Instance variable
    byte obj=25;

    //static variable
    static byte num=23;

    public static void str(){
        int age=4;
        System.out.println(age);
    }
    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int x;

        //local variable
        System.out.print("Enter a x value=");
        x=myObj.nextInt();
        System.out.println("local variable="+x);
        VariableType data=new VariableType();
        data.str();

        //static variable is printed
        System.out.println("\nStatic variable="+num);

        //Instance variable create object and value print.
        VariableType main=new VariableType();
        System.out.println("Instance variable="+main.obj);

    }
}
