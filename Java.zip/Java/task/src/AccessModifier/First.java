package AccessModifier;

class First {
    public void message(){

        System.out.println("This is a message");
    }
}