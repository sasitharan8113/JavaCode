package AccessModifier;
public class packages extends First{
    public static void main(String[] args) {
        First f=new First();
        f.message();
    }
}