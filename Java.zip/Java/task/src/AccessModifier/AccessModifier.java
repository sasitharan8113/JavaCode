package AccessModifier;
//public modifier

class A{
    public int data=40;
    public void msg(){
        System.out.println("Hello java");
    }
}

//private modifier
class c {
    private int input;

    public int getName(){

        return input;
    }

    public void getData(int input){

        this.input=input;
    }
    void display1(){

        System.out.println("Input value="+input);
    }

    protected void display2(){
        System.out.println("hello world");
    }
}




public class AccessModifier{
    public static void main(String args[]){
        A obj=new A();
        System.out.println(obj.data);
        obj.msg();

        c obj1=new c();
            obj1.getData(23);
            obj1.display1();
            obj1.display2();
    }
}  