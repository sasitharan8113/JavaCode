import java.util.Scanner;

public class StudentDetails {

    public static java.lang.String name(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Student name=");
        return myObj.nextLine();
    }
    //Total student in class method
    public static int count(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a array value=");
        return myObj.nextInt();
    }

    //Student id method
    public static long id(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Student ID=");
        return myObj.nextLong();
    }

    //Student age method
    public static int age(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Student Age=");
        return myObj.nextInt();
    }

    //Student Tamil mark method
    public static int tamilMark(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Tamil mark=");
        return myObj.nextInt();
    }

    //Student English mark method
    public static int englishMark(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a English mark=");
        return myObj.nextInt();
    }

    //Student Maths mark method
    public static int mathMark(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Maths mark=");
        return myObj.nextInt();
    }

    //Student Science mark method
    public static int scienceMark(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Science mark=");
        return myObj.nextInt();
    }

    ////Student Social Science mark method
    public static int socialMark(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a socialScience mark=");
        return myObj.nextInt();
    }

    public static void main(String[] args){
        int i,limitStudentDetails=0,studentAge,tamilSubjectMarks=0,englishSubjectMarks=0,mathSubjectMarks=0,
                scienceSubjectMarks=0,socialSubjectMarks=0,totalMark,condition=0;
        long studentId;
        Scanner myObj=new Scanner(System.in);
        while(condition!=1)
        {
            try {
                limitStudentDetails = count();
                //array concept using student details
                int studentArray[]=new int[limitStudentDetails];

                if ((limitStudentDetails > 0) && (limitStudentDetails<=5)) {
                    condition=1;
                } else {
                    System.out.println("Please enter a number which is greater than zero and less than 5");
                }

            }catch (Exception e){
                System.out.println("Wrong Datatype is used and please check correct datatype is used");
            }
        }

            for(i=0;i<limitStudentDetails;i++) {

                //student Personal Name
                String studentName = name();

                //Check the student id datatype
                condition = 0;
                while (condition != 1) {
                    try {
                        studentId = id();
                        if (studentId > 0 && studentId <= 999999999) {
                            condition = 1;
                        } else {
                            System.out.println("Id limit is 10 digits only and change the value");
                        }
                    }catch (Exception e) {
                        System.out.println("Wrong Datatype is used and please check correct datatype is used");
                        studentId = id();
                    }
                }

                //check the Student limit age and datatype.
                condition = 0;
                while (condition != 1) {
                    try {
                        studentAge = age();
                        if (studentAge > 0 && studentAge <= 100) {
                            condition = 1;
                        } else {
                            System.out.println("Please enter a number which is greater than zero and less than 100");
                        }
                    } catch (Exception e) {
                        System.out.println("Wrong Datatype is used and please check correct datatype is used");
                        studentAge = age();
                    }
                }

                //check the Student mark details and datatype
                // Tamil mark in student
                condition = 0;
                while (condition != 1)
                {
                    try {
                        tamilSubjectMarks = tamilMark();
                        if (tamilSubjectMarks <= 100 && tamilSubjectMarks > 0) {
                            condition = 1;
                        } else {
                            System.out.println("Mark limit is 100 and more value are not supported");
                        }
                    } catch (Exception e) {
                        System.out.println("Wrong Datatype is used and please check correct datatype is used");
                        tamilSubjectMarks = tamilMark();
                    }
                }

                // English mark in student
                condition=0;
                while (condition != 1) {
                    try {
                        englishSubjectMarks = englishMark();
                        if (englishSubjectMarks <= 100 && englishSubjectMarks > 0) {
                            condition = 1;
                        } else {
                            System.out.println("Mark limit is 100 and more value are not supported");
                        }
                    } catch (Exception e) {
                        System.out.println("Wrong Datatype is used and please check correct datatype is used");
                        englishSubjectMarks = englishMark();
                    }
                }

                // // Maths mark in student
                condition=0;
                while (condition != 1) {
                    try {
                        mathSubjectMarks = mathMark();
                        if (mathSubjectMarks <= 100 && mathSubjectMarks > 0) {
                            condition = 1;
                        } else {
                            System.out.println("Mark limit is 100 and more value are not supported");
                        }
                    } catch (Exception e) {
                        System.out.println("Wrong Datatype is used and please check correct datatype is used");
                        mathSubjectMarks = mathMark();
                    }
                }

                // Science mark in student
                condition=0;
                while (condition != 1) {
                    try {
                        scienceSubjectMarks = scienceMark();
                        if (scienceSubjectMarks <= 100 && scienceSubjectMarks > 0) {
                            condition = 1;
                        } else {
                            System.out.println("Mark limit is 100 and more value are not supported");
                        }
                    } catch (Exception e) {
                        System.out.println("Wrong Datatype is used and please check correct datatype is used");
                        scienceSubjectMarks = scienceMark();
                    }
                }

                // Social mark in student
                condition=0;
                while (condition != 1) {
                    try {
                        socialSubjectMarks = socialMark();
                        if (socialSubjectMarks <= 100 && scienceSubjectMarks > 0) {
                            condition = 1;
                        }
                    else{
                        System.out.println("Mark limit is 100 and more value are not supported");
                    }
                }catch(Exception e){
                    System.out.println("Wrong Datatype is used and please check correct datatype is used");
                    socialSubjectMarks = socialMark();
                }
            }

                //Student total mark
                totalMark = (tamilSubjectMarks + englishSubjectMarks + mathSubjectMarks + scienceSubjectMarks + socialSubjectMarks);
                System.out.println("Total mark="+totalMark);

                //Student Average
                int average=((totalMark/5));
                System.out.println("Student Average="+average);

                //Student pass or fail check
                if (tamilSubjectMarks> 35 && englishSubjectMarks>35 && mathSubjectMarks>35 && scienceSubjectMarks>35 && socialSubjectMarks>35) {
                    System.out.println(studentName + " is Pass Mark in Exam");
                } else {
                    System.out.println(studentName + " is Fail Mark in Exam");
                }
                System.out.println("Student "+studentName+" is details completed");
                System.out.println("---------------------------------------------------------------------------------");
            }
    }
}
