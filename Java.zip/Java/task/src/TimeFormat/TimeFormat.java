package TimeFormat;

import java.util.Scanner;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
public class TimeFormat {

    public static int size(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a for loop size=");
        return myObj.nextInt();
    }
    public static int date(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("change the date=");
        return myObj.nextInt();
    }

    public static int month(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("change the month=");
        return myObj.nextInt();
    }

    public static int year(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("change the Year=");
        return myObj.nextInt();
    }

    public static long longValue(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a number=");
        return myObj.nextLong();
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);

        //create the object of date and time.
        System.out.println("Today date and time:");
        LocalDateTime mySelf = LocalDateTime.now();
        System.out.println("Date and Time=" + mySelf);

        System.out.println("----------------------------------------------------------------");

        int condition = 0;
        int limit = 0;
        while (condition != 1) {
            try {
                limit = size();
                if (limit > 0 && limit <= 4) {
                    condition = 1;
                } else {
                    System.out.println("for loop size is 0 to 4");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition = 0;
        int changeDate = 0;
        while (condition != 1) {
            try {
                changeDate = date();
                if (changeDate >= -31 && changeDate <= 31) {
                    condition = 1;
                } else {
                    System.out.println("date limit is -31 to 31");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition = 0;
        int changeMonth = 0;
        while (condition != 1) {
            try {
                changeMonth = month();
                if (changeMonth >= 1 && changeMonth <= 12) {
                    condition = 1;
                } else {
                    System.out.println("Month limit is 1 to 12");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it");
            }
        }

        condition = 0;
        int changeYear = 0;
        while (condition != 1) {
            try {
                changeYear = year();
                if (changeYear <= 2023) {
                    condition = 1;
                } else {
                    System.out.println("year limit is 1000 to 2023");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it");
            }
        }

        //And calculate the before and after date based on the current date.
        Date getDate = null;
        for (int i = 0; i < limit; i++) {
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DATE, changeDate);
            c.add(Calendar.MONTH, changeMonth);
            c.add(Calendar.YEAR, changeYear);
            getDate = c.getTime();
        }
        System.out.println("change the date,time and year=" + getDate);

        System.out.println("----------------------------------------------------------------");

        System.out.println("Date format:");
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("1st format model:dd/MM/yyyy="+mySelf.format(myFormatObj));

        DateTimeFormatter myFormatObj1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        System.out.println("2nd format model:yyyy-MM-dd="+mySelf.format(myFormatObj1));

        DateTimeFormatter myFormatObj2 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        System.out.println("3rd format model:MM/dd/yyyy="+mySelf.format(myFormatObj2));

        DateTimeFormatter myFormatObj3 = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
        System.out.println("3rd format model:yyyy-MM-dd-HH-mm-ss="+mySelf.format(myFormatObj3));

        DateTimeFormatter myFormatObj4 = DateTimeFormatter.ofPattern("E, MMM dd yyyy");
        System.out.println("3rd format model:yyyy-MM-dd-HH-mm-ss="+mySelf.format(myFormatObj4));

        System.out.println("----------------------------------------------------------------");
            condition = 0;
            long longDate = 0;
            while (condition != 1) {
                try {
                    longDate = longValue();
                    if (longDate>0 && longDate <= 9999999999999l) {
                        condition = 1;
                    } else {
                        System.out.println("long limit is 0 to 15 digit");
                    }
                } catch (Exception e) {
                    System.out.println("Wrong datatype is used and check it");
                }
            }
            System.out.println("Long Value to convert to Date Format:");
            Date date1=new Date(longDate);
            System.out.println("Date format="+date1);

        System.out.println("----------------------------------------------------------------");

        System.out.println("Current UTC time format:");
        Instant demo = Instant.now();
        java.lang.String utc = demo.toString();
        System.out.println("current UTC time="+utc);

        System.out.println("----------------------------------------------------------------");
    }
}
