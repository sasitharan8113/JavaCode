package Objectcloning;

import java.util.Scanner;

class Student implements Cloneable{
    private Object name;
    private int regNo;
    private static int mark1;
    private static int mark2;
    private static int mark3;
    private int result;
    private String collegeName;
    private int collegeCode;
    private double percentage;

    public void studentDetails(String name, int regNo, int mark1, int mark2, int mark3, int result){
        this.name=name;
        this.regNo=regNo;
        this.mark1=mark1;
        this.mark2=mark2;
        this.mark3=mark3;
        this.result=result;
    }

    public void display(){
        System.out.println("Student name="+name);
        System.out.println("Student regNo="+regNo);
        System.out.println("Student Mark1="+mark1);
        System.out.println("Student Mark2="+mark2);
        System.out.println("Student Mark3="+mark3);
        System.out.println("Student Exam result="+result);
    }

    public void collegeDetails(String collegeName,int collegeCode){
        this.collegeName=collegeName;
        this.collegeCode=collegeCode;
    }

    public void display1(){
        System.out.println("Enter a college name="+collegeName);
        System.out.println("Enter a college code="+collegeCode);
    }

    public void studentPercentage(double percentage){
        this.percentage=percentage;
    }

    public void display2(){
        System.out.println("student percentage="+percentage);
    }

    public static String studentName(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a student Name=");
        return myObj.nextLine();
    }

    public static int studentRegNo(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a student Id=");
        return myObj.nextInt();
    }

    public static int studentMark1(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a student Mark1=");
        return myObj.nextInt();
    }

    public static int studentMark2(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a student Mark2=");
        return myObj.nextInt();
    }
    public static int studentMark3(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a student Mark3=");
        return myObj.nextInt();
    }

    public static String studentCollegeName(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a college name=");
        return myObj.nextLine();
    }

    public static int studentCollegeCode(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a college code=");
        return myObj.nextInt();
    }

    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

}

public class cloning {
    public static void main(String[] args) throws CloneNotSupportedException {
        Scanner myObj = new Scanner(System.in);
        Student details = new Student();

        String name = details.studentName();

        int condition = 0;
        int regNo = 0;
        while (condition != 1) {
            try {
                regNo = details.studentRegNo();
                if (regNo > 0 && regNo <= 100) {
                    condition = 1;
                } else {
                    System.out.println("Student id limit is 1 to 100.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and correct it.");
            }
        }

        condition = 0;
        int mark1 = 0;
        while (condition != 1) {
            try {
                mark1 = details.studentMark1();
                if (mark1 > 0 && mark1 <= 100) {
                    condition = 1;
                } else {
                    System.out.println("Student mark limit is 1 to 100.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and correct it.");
            }
        }

        condition = 0;
        int mark2 = 0;
        while (condition != 1) {
            try {
                mark2 = details.studentMark2();
                if (mark2 > 0 && mark2 <= 100) {
                    condition = 1;
                } else {
                    System.out.println("Student mark limit is 1 to 100.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and correct it.");
            }
        }

        condition = 0;
        int mark3 = 0;
        while (condition != 1) {
            try {
                mark3 = details.studentMark3();
                if (mark3 > 0 && mark3 <= 100) {
                    condition = 1;
                } else {
                    System.out.println("Student mark limit is 1 to 100.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and correct it.");
            }
        }

        int result=mark1+mark2+mark3;
        System.out.println("Student total mark="+result);

        System.out.println("----------------------------------------------------------");

        System.out.println("Student academic detail:");
        details.studentDetails(name, regNo, mark1, mark2, mark3, result);
        details.display();

        System.out.println("----------------------------------------------------------");

        String collegeName=details.studentCollegeName();
        condition=0;
        int collegeCode=0;
        while (condition != 1) {
            try {
                collegeCode = details.studentCollegeCode();
                if (collegeCode > 1000 && collegeCode <= 9999) {
                    condition = 1;
                } else {
                    System.out.println("Student mark limit is 1000 to 9999.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and correct it.");
            }
        }
        System.out.println("----------------------------------------------------------");

        System.out.println("College Details:");
        details.collegeDetails(collegeName,collegeCode);
        details.display1();

        System.out.println("----------------------------------------------------------");

        double percentage=0;
        percentage=(result/3);
        System.out.println("Student percentage:");
        details.studentPercentage(percentage);
        details.display2();

        System.out.println("----------------------------------------------------------");

        System.out.println("object cloning:");
        Student details1=(Student)details.clone();
        details1.studentDetails(name,regNo,mark1,mark2,mark3,result);
        details1.display();

        details1.collegeDetails(collegeName,collegeCode);
        details1.display1();

        details.studentPercentage(percentage);
        details.display2();

        System.out.println("----------------------------------------------------------");
    }

}
