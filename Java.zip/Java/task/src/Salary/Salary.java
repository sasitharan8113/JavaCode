package Salary;

import java.util.Scanner;

class GrossSalary{
    protected double epf;
    protected double esi;
    protected double tax;
    protected double losePay;
    protected double totalDeduction;
    private double basicSalary;
    private double houseRentAllowance;
    private double dearNessAllowance;
    private double medicalAllowance;
    private double grossIncome;

    public void getData(double basicSalary, double houseRentAllowance, double dearNessAllowance, double medicalAllowance, double grossIncome){
    this.basicSalary=basicSalary;
    this.houseRentAllowance=houseRentAllowance;
    this.dearNessAllowance=dearNessAllowance;
    this.medicalAllowance=medicalAllowance;
    this.grossIncome=grossIncome;
    }

    public void display(){
        System.out.println("Enter a basic salary="+basicSalary);
        System.out.println("Enter a house rent allowance="+houseRentAllowance);
        System.out.println("Enter a dearness Allowance="+dearNessAllowance);
        System.out.println("Enter a medical Allowance="+medicalAllowance);
        System.out.println("Gross salary="+grossIncome);
    }

    public static double salaryDetails(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a basic salary=");
        return myObj.nextDouble();
    }

}

class Deduction extends GrossSalary{
    public void getData1(double epf, double esi, double tax, double losePay,double totalDeduction){
        super.epf=epf;
        super.esi=esi;
        super.tax=tax;
        super.losePay=losePay;
        super.totalDeduction=totalDeduction;
    }

    public void display1(){
        System.out.println("Enter a pf amount="+epf);
        System.out.println("Enter a esi amount="+esi);
        System.out.println("Enter a tax amount="+tax);
        System.out.println("Enter a lose pay amount="+losePay);
        System.out.println("Enter a Total Deduction="+totalDeduction);
    }

    public static int pay(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a leave day=");
        return myObj.nextInt();
    }
}
public class Salary {
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        Deduction demo = new Deduction();
        int condition = 0;
        double basicSalary = 0, dearNessAllowance = 0;
        while (condition != 1) {
            try {
                basicSalary = demo.salaryDetails();
                if (basicSalary > 10000 && basicSalary < 120000) {
                    condition = 1;
                } else {
                    System.out.println("salary limit is 10000 to 120000");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it");
            }
        }
        double houseRentAllowance = (basicSalary * 0.4);
        dearNessAllowance = (basicSalary * 0.34);
        double medicalAllowance = basicSalary + 1250;
        double grossIncome = basicSalary + houseRentAllowance+dearNessAllowance + medicalAllowance;

        System.out.println("------------------------------------------------------------------------------");
        System.out.println("Salary allowance calculation");

        //method call

        demo.getData(basicSalary, houseRentAllowance,dearNessAllowance, medicalAllowance, grossIncome);
        demo.display();

        System.out.println("------------------------------------------------------------------------------");

        //pf calculation
        double epf;
        if(grossIncome<=42000){
            epf=grossIncome*0.12;
        }else{
            epf=grossIncome*0.083;
        }

        //esi deduction
        double esi = grossIncome * 0.035;

        //tax deduction
        double tax;
        if(grossIncome>45834 && grossIncome<=62500){
            tax = (grossIncome* 0.1);
        }else if(grossIncome>62500 && grossIncome<=83333){
            tax=(grossIncome*0.15);
        } else if (grossIncome>83333 && grossIncome<=104167) {
            tax=(grossIncome*0.2);
        } else if (grossIncome>104167 && grossIncome<=12500) {
            tax=(grossIncome*0.25);
        }else{
            tax=0;
        }

        //lose pay
        int employeeLosePay=0;
        condition=0;
        while (condition != 1) {
            try {
                employeeLosePay = demo.pay();
                if (employeeLosePay >= 2) {
                    condition = 1;
                } else {
                    System.out.println("leave limit is 2 day only.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }
        double leaveDay=grossIncome/30;
        double losePay = leaveDay * employeeLosePay;
        double totalDeduction = grossIncome - (epf + esi + tax + losePay);
        demo.getData1(epf,esi,tax,losePay,totalDeduction);
        demo.display1();
        System.out.println("------------------------------------------------------------------------------");

        System.out.println("Employee salary="+String.format("%.2f",totalDeduction));

        System.out.println("------------------------------------------------------------------------------");

        double ctc=(totalDeduction*12);
        System.out.println("CTC="+String.format("%.2f",ctc));

        if(ctc>550000){
            System.out.println("This employee is eligible to Income tax payable.");
        }else{
            System.out.println("employee is not eligible to Income tax payable");
        }
        System.out.println("------------------------------------------------------------------------------");


    }
}
