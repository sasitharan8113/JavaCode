package SimpleTask;

import java.util.Arrays;
import java.util.Scanner;

public class SimpleTask
{
    static int sum=0,num,sum1=0,num1,num2,num3,sum2=0;
    public static int values(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a value=");
        return myObj.nextInt();
    }

    //sum of digit method
    public static int som(int number){
        while(number>0){
            num=number%10;
            sum=sum+num;
            number=number/10;
        }
        return sum;
    }

    //Reverse of Integer
    public static int reverse(int number){
        while(number>0){
            num1=number%10;
            sum1=(sum1*10)+num1;
            number=number/10;
        }
        return sum1;
    }

    //integer convert to array
    public static int[] count(int number){
        String temp = Integer.toString(number);
        int[] arr = new int[temp.length()];
        for (int i = 0; i < temp.length(); i++) {
            arr[i] =  Character.getNumericValue(temp.charAt(i));
        }
        System.out.println(Arrays.toString(arr));
        return arr;
    }
    //create the index value
    public static int index(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Index position:");
        return myObj.nextInt();
    }
    public static int rePlace(){
        Scanner myObj = new Scanner(System.in);
        System.out.print("Index replacement position value:");
        int rePlaceElement=myObj.nextInt();;
        return rePlaceElement;
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        int number = 0, condition = 0;
        while (condition != 1) {
            try {
                number = values();
                if (number > 0 && number <= 999999) {
                    condition = 1;
                } else {
                    System.out.println("values is greater than 0 and also 6 digit values only used");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }

        //Sum of digit
        System.out.println("\nSum Of Digit program:");
        int sumOfDigit = som(number);
        System.out.println("Sum Of Digits=" + sumOfDigit);
        System.out.println("-------------------------------------------------------------------------");

        //Reverse integer
        System.out.println("Reverse Integer program:");
        int reverseOfInteger = reverse(number);
        System.out.println("Reverse Integer=" + reverseOfInteger);
        System.out.println("-------------------------------------------------------------------------");

        //integer count
        System.out.println("Integer count:");
        int[] intCount = count(number);
        int countLength = intCount.length;
        System.out.println("Integer count=" + countLength);
        System.out.println("-------------------------------------------------------------------------");

        //Average
        System.out.println("Average of sum of digit:");
        int average = sumOfDigit / countLength;
        System.out.println("Average=" + average);
        System.out.println("-------------------------------------------------------------------------");

        //Armstrong Number
        System.out.println("Armstrong number:");
        int number1=number;
        while (number1 > 0) {
            num2 = number1 % 10;
            sum2 =sum2+ (int) Math.pow(num2, countLength);
            number1 = number1 / 10;
        }
        if (sum2 == number) {
            System.out.println(number + " is armstrong number");
        } else {
            System.out.println(number + " is not armstrong number");
        }
        System.out.println("-------------------------------------------------------------------------");

        //biggest number
        System.out.println("Biggest number in array:");
        int max = 0;
        max = intCount[0];
        for (int i = 0; i < countLength; i++) {
            if (intCount[i] > max) {
                max = intCount[i];
            }
        }
        System.out.println("Biggest number=" + max);
        System.out.println("-------------------------------------------------------------------------");

        //smallest number
        System.out.println("Smallest number in array:");
        int min = 0;
        min = intCount[0];
        for (int i = 0; i < countLength; i++) {
            if (intCount[i] < min) {
                min = intCount[i];
            }
        }
        System.out.println("Smallest number=" + min);
        System.out.println("-------------------------------------------------------------------------");

        //Index position value
        System.out.println("check the Index position:");
        condition = 0;
        int indexValue = 0;
        while (condition != 1) {
            indexValue = index();
            try {
                if (indexValue >= 0 && indexValue <= countLength) {
                    condition = 1;
                } else {
                    System.out.println("array limit is reached and change index value");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        System.out.println("Index position number=" + intCount[indexValue]);
        System.out.println("-------------------------------------------------------------------------");

        //Repeating number in array
        System.out.println("Repeat number in array:");
        int check = 0;
        System.out.print("Repeat element=");
        for (int i = 0; i < countLength; i++) {
            for (int j = i + 1; j < countLength; j++) {
                if (intCount[i] == intCount[j]) {
                    System.out.print(intCount[j]+" ");
                    check=1;
                    break;
                }
            }
        }
        if (check == 0) {
            System.out.println("No repeat element in array");
        }
        System.out.println("\n-------------------------------------------------------------------------");

        //Mid element in array
        int midElement = countLength / 2;
        System.out.println("Mid element in array=" + intCount[midElement]);
        System.out.println("-------------------------------------------------------------------------");

        //number convert into string format
        System.out.println("Display string format:");
        for (int i = 0; i < countLength; i++) {
            switch (intCount[i]) {
                case 1:
                    System.out.println("one");
                    break;
                case 2:
                    System.out.println("Two");
                    break;
                case 3:
                    System.out.println("Three");
                    break;
                case 4:
                    System.out.println("Four");
                    break;
                case 5:
                    System.out.println("Five");
                    break;
                case 6:
                    System.out.println("Six");
                    break;
                case 7:
                    System.out.println("Seven");
                    break;
                case 8:
                    System.out.println("Eight");
                    break;
                case 9:
                    System.out.println("Nine");
                    break;
                case 0:
                    System.out.println("Zero");
            }
            number = number / 10;
        }
        System.out.println("-------------------------------------------------------------------------");

        //Replace array element
        System.out.println("Replacement value into array element:");
        condition = 0;
        int rePlaceElement = 0;
        while (condition != 1) {
            rePlaceElement = rePlace();
            try {
                if (rePlaceElement >=0 && rePlaceElement <= countLength) {
                    condition = 1;
                } else {
                    System.out.println("array limit is reached and change index value");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and change the datatype value");
            }
        }
        System.out.print("change the number of value:");
        int change=myObj.nextInt();
        intCount[rePlaceElement] = change;
        System.out.print("Replace array element=");
        for (int i = 0; i < countLength; i++) {
            System.out.print(intCount[i] + " ");
        }
        System.out.println("\n-------------------------------------------------------------------------");

        //Appearance
        System.out.println("Frequency number in array:");
        int count,i,j,temp=0;
        for(i=0;i<countLength;i++){
            for(j=i+1;j<countLength;j++){
                if(intCount[i]>intCount[j]){
                    temp=intCount[i];
                    intCount[i]=intCount[j];
                    intCount[j]=temp;
                }
            }
        }
            for (i = 0; i < countLength; i++) {
                count = 1;
                for (j = i + 1; j < countLength; j++) {
                    if (intCount[i] == intCount[j]) {
                        count++;
                    } else {
                       break;
                    }
                }
                i = j - 1;
                if (count >= 1) {
                    System.out.println("The element is " + intCount[i] + " and its frequency is " + count);
                }
            }
        System.out.println("-------------------------------------------------------------------------");
    }
}
