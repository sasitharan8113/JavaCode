package MathFunction;
import java.util.Scanner;
public class MethodOverloading {

    //Math.abs() Method
    public static void function(int absolute){
        System.out.println("Result="+Math.abs(absolute));
    }

    //Math.round() Method
    public static void function(Double decimal){
        System.out.println("Result="+Math.round(decimal));
    }

    //Math.sqrt() Method
    public static byte function(byte square){
        return (byte) Math.sqrt(square);
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);

        //create the object
        MethodOverloading result=new MethodOverloading();

        //check the error in absolute value.
        System.out.println("Math Absolute method:");
        int condition = 0;
        int absolute = 0;
        while (condition != 1) {
            try {
                absolute=abs();
                if (absolute < 0) {
                    condition = 1;
                } else {
                    System.out.println("absolute value limit is 4 digit.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check the correct datatype.");
            }
        }

        //absolute method call

        result.function(absolute);

        System.out.println("-----------------------------------------------------------------------");
        //check the error in round value.
        System.out.println("Math Round method:");
        condition=0;
        Double decimal = 0.0;
        while (condition != 1) {
            try {
                decimal = round();
                if (decimal>0.0 && decimal<9999.99) {
                    condition = 1;
                } else {
                    System.out.println("decimal value limit is 4 digit.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check the correct datatype.");
            }
        }

        //round method call
        result.function(decimal);

        System.out.println("-----------------------------------------------------------------------");

        //check the error in square value.
        System.out.println("Math Round method:");
        condition=0;
        byte square = 0;
        while (condition != 1) {
            try {
                square = squareValue();
                if (square>0 && square <= 233) {
                    condition = 1;
                } else {
                    System.out.println("square value limit is 233 number.");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check the correct datatype.");
            }
        }

        //square method call
        System.out.println("Result="+result.function(square));

        System.out.println("-----------------------------------------------------------------------");

        //Math.log() method
        System.out.println("Math log method="+Math.log(square));

        System.out.println("-----------------------------------------------------------------------");

        //Math.sin() method
        System.out.println("Math sin method="+Math.sin(square));

        System.out.println("-----------------------------------------------------------------------");

        //Math.cos() method
        System.out.println("Math cos method="+Math.cos(square));

        System.out.println("-----------------------------------------------------------------------");

        //Math.tan() method
        System.out.println("Math tan method="+Math.tan(square));

        System.out.println("-----------------------------------------------------------------------");

        //Math.ceil() method
        System.out.println("Math ceil method="+Math.ceil(decimal));

        System.out.println("-----------------------------------------------------------------------");

        //Math.floor() method
        System.out.println("Math tan method="+Math.floor(decimal));

        System.out.println("-----------------------------------------------------------------------");
    }
    public static int abs(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a absolute value=");
        return myObj.nextInt();
    }

    public static Double round(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a round value=");
        return myObj.nextDouble();
    }

    public static byte squareValue(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Square value=");
        return myObj.nextByte();
    }
}
