import java.util.Scanner;
import java.math.BigInteger;
public class FibonacciSeries {
    public static long size(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a size value=");
        return myObj.nextInt();
    }

    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);
        int condition=0,i;
        long seriesLength=0;
        BigInteger n1=BigInteger.valueOf(0);
        BigInteger n2=BigInteger.valueOf(1);
        while(condition!=1){
            try{
                seriesLength=size();
                if(seriesLength>0 && seriesLength<=999999){
                    condition=1;
                }else{
                    System.out.println("Please enter a number which is greater than zero and less than 6 digit");
                }
            }catch(Exception e){
                System.out.println("Wrong datatype is used and so change the datatype");
                seriesLength=size();
            }
        }
        System.out.println("Fibonacci series="+n1+""+n2);
        for(i=0;i<=seriesLength;i++){
           BigInteger n3=n1.add(n2);
            System.out.println(" "+n3);
            n1=n2;
            n2=n3;
        }
    }
}
