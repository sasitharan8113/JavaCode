package MethodOverriding;

import java.util.Scanner;

class AxisBank{
    double interestRate;

    public double getData(double interestRate){
        this.interestRate=interestRate;
        return interestRate;
    }

    public void display(){
        System.out.println("Axis bank interest rate="+interestRate);
    }
}

class HdfcBank extends AxisBank{
    double interestRate=13.75;

    public double getData(double interestRate){
        this.interestRate=interestRate;
        return interestRate;
    }

    public void display(){
        System.out.println("HDFC bank interest rate="+interestRate);
    }
}

class IcicBank extends HdfcBank{
    double interestRate;

    public double getData(double interestRate){
        this.interestRate=interestRate;
        return interestRate;
    }

    public void display(){
        System.out.println("ICICI bank interest rate="+interestRate);
    }
}

class SbiBank extends IcicBank{
    double interestRate;

    public double getData(double interestRate){
        this.interestRate=interestRate;
        return interestRate;
    }

    public void display(){
        System.out.println("SBI bank interest rate="+interestRate);
    }
}

class IobBank extends SbiBank{
    double interestRate;

    public double getData(double interestRate){
        this.interestRate=interestRate;
        return interestRate;
    }

    public void display(){
        System.out.println("IOB bank interest rate="+interestRate);
    }
}


public class MethodOverriding {
    public static String employeeName;

    public static int employeeId;

    public static String employeeRole;

    public static int employeeCtc;

    public  static int employeeBasicPay;

    public  static int loanAmount;

    public  static int monthEmi;

    public  static String bankName;

    public static String name() {
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a employee name=");
        return myObj.nextLine();
    }

    public static int id(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a employee id=");
        return myObj.nextInt();
    }

    public static String role(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a employee role=");
        return myObj.nextLine();
    }

    public static int ctc(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a employee CTC=");
        return myObj.nextInt();
    }

    public static int pay(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a employee basic pay=");
        return myObj.nextInt();
    }

    public static int amount(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a employee loan amount=");
        return myObj.nextInt();
    }

    public static int month(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a number of month EMI=");
        return myObj.nextInt();
    }

    public static String number(){
        Scanner myObj=new Scanner(System.in);
        System.out.print("Enter a Bank name=");
        return myObj.nextLine();
    }

    public static void main(String[] args) {
        Scanner myObj=new Scanner(System.in);

        System.out.println("Employee & Loan Details");
        //employee name method call
        employeeName=name();

        //employee id method call & check error
        int condition=0;
        while (condition != 1) {
            try {
                employeeId = id();
                if (employeeId > 0 && employeeId <= 9999) {
                    condition = 1;
                } else {
                    System.out.println("id limit is 1 to 9999");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //employee role method call & check error
        employeeRole = role();

        //employee ctc method call & check error
        condition=0;
        while (condition != 1) {
            try {
                employeeCtc = ctc();
                if (employeeCtc > 120000 && employeeCtc <= 1200000) {
                    condition = 1;
                } else {
                    System.out.println("ctc limit is 1 lakhs to 12 lakhs");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //employee basic salary method call & check error
        condition=0;
        while (condition != 1) {
            try {
                employeeBasicPay = pay();
                if (employeeBasicPay > 10000 && employeeBasicPay <= 100000) {
                    condition = 1;
                } else {
                    System.out.println("basic salary limit is 10000 to 100000");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //Loan amount method call
        condition=0;
        while (condition != 1) {
            try {
                loanAmount = amount();
                if (loanAmount > 120000 && loanAmount <= 700000) {
                    condition = 1;
                } else {
                    System.out.println("loan amount limit is 1.2 lakhs to 7 lakhs");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        //total emi month method call
        condition=0;
        while (condition != 1) {
            try {
                monthEmi = month();
                if (monthEmi > 12 && monthEmi <= 60) {
                    condition = 1;
                } else {
                    System.out.println("EMI month range is 13 month to 60 month");
                }
            } catch (Exception e) {
                System.out.println("Wrong datatype is used and check it.");
            }
        }

        System.out.println("----------------------------------------------------------------------------");

        //choose the Bank and check the error.
        System.out.println("Bank interest details:");
        //create the object.
        AxisBank demo=new AxisBank();
        double axis=demo.getData(13.00);
        demo.display();

        HdfcBank demo1=new HdfcBank();
        double hdfc=demo1.getData(12.00);
        demo1.display();

        IcicBank demo2=new IcicBank();
        double icici=demo2.getData(14.00);
        demo2.display();

        SbiBank demo3=new SbiBank();
        double sbi=demo3.getData(12.00);
        demo3.display();

        IobBank demo4=new IobBank();
        double iob=demo4.getData(11.25);
        demo4.display();

        System.out.println("----------------------------------------------------------------------------");
        System.out.println("Loan interest rate details:");
        //Switch case
        condition=0;
        while(condition!=1){
            try{
                bankName = number();
                switch (bankName){
                    case "axis":
                        double emi =(loanAmount*(monthEmi/12)*axis)/100;
                        System.out.println("Loan amount="+loanAmount);
                        System.out.println("No of month in EMI="+monthEmi);
                        System.out.println("Bank=Axis Bank::Interest=13%");
                        System.out.println("Total EMI Amount="+emi);
                        System.out.println("Per month EMI ="+String.format("%.2f",(emi/monthEmi)));
                        condition=1;
                        break;
                    case "hdfc":
                        double emi1 = (loanAmount * (monthEmi / 12) * hdfc) / 100;
                        System.out.println("Loan amount="+loanAmount);
                        System.out.println("No of month in EMI="+monthEmi);
                        System.out.println("Bank=HDFC Bank::Interest=12%");
                        System.out.println("Total EMI Amount="+emi1);
                        System.out.println("Per month EMI ="+String.format("%.2f",(emi1/monthEmi)));
                        condition=1;
                        break;
                    case "icici":
                        double emi2 = (loanAmount * (monthEmi / 12) * icici)/ 100;
                        System.out.println("Loan amount="+loanAmount);
                        System.out.println("No of month in EMI="+monthEmi);
                        System.out.println("Bank=ICICI Bank::Interest=14%");
                        System.out.println("Total EMI Amount="+emi2);
                        System.out.println("Per month EMI ="+String.format("%.2f",(emi2/monthEmi)));
                        condition=1;
                        break;
                    case "sbi":
                        double emi3 = (loanAmount * (monthEmi / 12) * sbi)/ 100;
                        System.out.println("Loan amount="+loanAmount);
                        System.out.println("No of month in EMI="+monthEmi);
                        System.out.println("Bank=SBI Bank::Interest=12%");
                        System.out.println("Total EMI Amount="+emi3);
                        System.out.println("Per month EMI ="+String.format("%.2f",(emi3/monthEmi)));
                        condition=1;
                        break;
                    case "iob":
                        double emi4 = (loanAmount * (monthEmi / 12) * iob) / 100;
                        System.out.println("Loan amount="+loanAmount);
                        System.out.println("No of month in EMI="+monthEmi);
                        System.out.println("Bank=IOB Bank::Interest=11.25%");
                        System.out.println("Total EMI Amount="+emi4);
                        System.out.println("Per month EMI ="+String.format("%.2f",(emi4/monthEmi)));
                        condition=1;
                        break;
                    default:
                        System.out.println("Invalid input");
                        break;
                }
            }catch (Exception e){
                System.out.println("error");
            }
        }
        System.out.println("----------------------------------------------------------------------------");
    }
}
